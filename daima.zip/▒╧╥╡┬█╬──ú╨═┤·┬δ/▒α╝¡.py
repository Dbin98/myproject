#!/user/bin/env python
# -*- coding: utf-8 -*-
# @Time    :2021/3/11 11:17
# @Author  :Alive
# @Site    :
# @File    :编辑.py
# @Software:PyCharm
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import CountVectorizer
df = []
n_features = 1000
tf_vectorizer = CountVectorizer(strip_accents='unicode',
                                max_features=n_features,
                                stop_words=None,
                                max_df=0.8,
                                min_df=0.01)
tf = tf_vectorizer.fit_transform(df.fenci)

from sklearn.decomposition import LatentDirichletAllocation

topic_list = []
perplexity_list = []

for n_topics in range(30):  # 循环数，看聚类多少类进行评价,根据困惑度,最小的即为最好的类别
    lda = LatentDirichletAllocation(n_components=n_topics + 2,
                                    max_iter=100,
                                    learning_method='online',
                                    learning_offset=50,
                                    random_state=0)
    lda.fit(tf)
    # lda困惑度计算
    perplexity_list.append(lda.perplexity(tf))
    topic_list.append(n_topics)
    print("主题数{}的困惑度：{}".format(str(n_topics), lda.perplexity(tf)))


def graph_draw(topic, perplexity,):
    # 做主题数与困惑度的折线图
    x = topic
    y = perplexity
    plt.plot(x, y, color="red", linewidth=2)
    plt.xlabel("Number of Topic")
    plt.ylabel("Perplexity")
    plt.show()


graph_draw(topic_list, perplexity_list)

fenci_list = []
for item in df.fenci:
    itemlist = item.split(',')
    for i in itemlist:
        if i != ' ':
            fenci_list.append(i)
dis = {}
dict = []
for word in fenci_list:
    if len(word)>1 :
        if word not in dis:
            dis[word] = 1
        else:
            dis[word] = dis[word] + 1
word_list = list(dis.items())
word_list.sort(key=lambda x: x[1], reverse=True)
for i in range(1000):
    dict.append(word_list[i][0])

texts = []