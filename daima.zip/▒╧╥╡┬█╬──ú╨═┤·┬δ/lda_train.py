#!/user/bin/env python
# -*- coding: utf-8 -*-
# @Time    :2021/3/10 10:36
# @Author  :Alive
# @Site    :
# @File    :lda_train.py
# @Software:PyCharm
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer

# 打开文件
df = pd.read_csv('fenci.csv', encoding='gb18030')  # 分词结果，默认第一行为索引
df = df.dropna()


def stopword_list(filepath):  # 加载停用词
    stopwords = [line.strip() for line in open(filepath, 'r', encoding='utf-8').readlines()]
    return stopwords


stopwords = stopword_list('stopwords.txt')  # 加载停用词路径
# tfidf 矩阵
n_features = 1000
tf_vectorizer = CountVectorizer(strip_accents='unicode',
                                max_features=n_features,
                                stop_words=stopwords,
                                max_df=0.5,
                                min_df=0.01)
tf = tf_vectorizer.fit_transform(df.fenci)

from sklearn.decomposition import LatentDirichletAllocation

n_topics = 20
# lda处理
lda = LatentDirichletAllocation(n_components=n_topics, max_iter=50,
                                learning_method='online',
                                learning_offset=50,
                                random_state=0)

# lda训练
lda.fit(tf)
# nps = np.log(lda.components_)
# print(nps)
# npsDf = pd.DataFrame(nps)
# npsDf.to_csv('term_topics.csv')
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
print("test", lda.components_)
topic_word_dist = lda.components_
topic_word = pd.DataFrame(topic_word_dist)
sum = topic_word.sum(axis=0)
print(sum)
p = topic_word.div(sum, axis=0)
print(p)
print(lda.components_)


def print_top_words(model, feature_names, n_top_words):
    for topic_idx, topic in enumerate(model.components_):  # model.components_:主题-词语分布矩阵；enumerate同时获取索引和值
        print("Topic %d:" % topic_idx)
        print(" ".join(
            [feature_names[i] for i in topic.argsort()[:-n_top_words - 1:-1]]))  # argsort()将topic中的元素从小到大排列，提取对应的索引


n_top_words = 2
tf_feature_names = tf_vectorizer.get_feature_names()  # 文档生产的字典
print_top_words(lda, tf_feature_names, n_top_words)

# 根据LDA运行结果，对文档分类
doc_topic_dist = lda.transform(tf)  # 文档主题矩阵
arr = pd.DataFrame(doc_topic_dist)  # 转化为DataFrame格式
row = len(arr)
print("document,topic")
index = []
for i in range(0, row):
    doc = arr.loc[i, :]  # 获取第i-1行数据
    doc_list = list(doc)
    i_argmax = doc_list.index(max(doc_list))  # 列表中最大值对应的索引，即为概率最大值对应的topic
    index.append(i_argmax)
    print(i, i_argmax)  # 输出文档和对应的topic

indexDf = pd.DataFrame(index)
indexDf.to_csv('doc_topic.csv')
