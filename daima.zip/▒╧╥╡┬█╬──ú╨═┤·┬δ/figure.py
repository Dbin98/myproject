#!/user/bin/env python
# -*- coding: utf-8 -*-
# @Time    :2021/3/10 10:24
# @Author  :Alive
# @Site    :
# @File    :figure.py
# @Software:PyCharm

from gensim import corpora, models, similarities
import pandas as pd

# 打开文件
df = pd.read_csv('fenci.csv', encoding='gb18030')  # 分词结果，默认第一行为索引
df = df.dropna()
documents = list(df.fenci)

fenci_list = []
for item in df.fenci:
    itemlist = item.split(',')
    for i in itemlist:
        if i != '\t':
            fenci_list.append(i)
dis = {}
dict = []
for word in fenci_list:
    if len(word)>1 :
        if word not in dis:
            dis[word] = 1
        else:
            dis[word] = dis[word] + 1
word_list = list(dis.items())
word_list.sort(key=lambda x: x[1], reverse=True)
for i in range(100):
    dic=str(word_list[i][0])
    fre = word_list[i][1]
    dict.append([dic,fre])







