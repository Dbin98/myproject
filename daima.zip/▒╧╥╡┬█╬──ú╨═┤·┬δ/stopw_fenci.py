#!/user/bin/env python
# -*- coding: utf-8 -*-
# @Time    :2021/3/10 10:03
# @Author  :Alive
# @Site    :
# @File    :stopw_fenci.py
# @Software:PyCharm

import pandas as pd
import wordcloud
import jieba

# 读取数据

df = pd.read_csv('new_data.csv', encoding='GBK')
print(df.isna().sum())


def stopword_list(filepath):  # 加载停用词
    stopwords = [line.strip() for line in open(filepath, 'r', encoding='utf-8').readlines()]
    return stopwords


# 分词
def seg_sentence(sentence):
    sentence_seged = sentence.strip(' ')
    sentence_seged = jieba._lcut(sentence_seged)
    # print("/".join(sentence_seged))
    stopwords = stopword_list('stopwords.txt')  # 加载停用词路径
    outstr = ''
    for word in sentence_seged:
        if word not in stopwords:
            if word != '\t':
                outstr += word
                outstr += ','
    return outstr


inputs = df['内容']

# 新建分词结果列
outputs = df["fenci"]

line_seg = []
for line in inputs:
    line_seg.append(seg_sentence(line))
name = ["fenci"]
test = pd.DataFrame(columns=name, data=line_seg)
print(test.isna().sum())
test.to_csv('fenci1.csv', encoding='gb18030',index=True)
