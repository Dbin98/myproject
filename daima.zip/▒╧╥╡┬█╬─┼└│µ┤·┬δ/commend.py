#!/user/bin/env python
# -*- coding: utf-8 -*-
# @Time    :2021/3/9 12:53
# @Author  :Alive
# @Site    :
# @File    :commend.py
# @Software:PyCharm
import csv
import random
import time
import pandas as pd
import requests
import re
head_list=["Opera/9.80 (X11; Linux i686; Ubuntu/14.10) Presto/2.12.388 Version/12.16",
    "Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14",
    "Mozilla/5.0 (Windows NT 6.0; rv:2.0) Gecko/20100101 Firefox/4.0 Opera 12.14",
    "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0) Opera 12.14",
    "Opera/12.80 (Windows NT 5.1; U; en) Presto/2.10.289 Version/12.02",
   ]
ip=['114.101.42.16:65309',
    '220.179.255.7:8118',
    '103.44.145.182:8080',
    '115.223.7.110:80']
proxy={'http':random.choice(ip)}
header={'user-agent':random.choice(head_list)}
fileHeader = ["id","评论时间", "用户id", "昵称", "评论内容"]
count = 0
def csv_data(fileHeader):
    with open("主题一.csv", "a", newline="") as fp:
        write = csv.writer(fp)
        write.writerow(fileHeader)

def get_id_list():
    id = []
    url_list = pd.read_csv('url_list.csv')
    for url in url_list['url']:
        mid = url.split('/')[-1]
        id.append(mid)
    return id

def get_url(id):
    base_url = 'https://m.weibo.cn/comments/hotflow?id={}&mid={}&max_id_type=0'
    url = base_url.format(id, id)
    return url

def get_next_url(id,max_id, max_id_type):
    base_next = 'https://m.weibo.cn/comments/hotflow?id={}&mid={}&max_id={}&max_id_type={}'
    next_url = base_next.format(id,id,max_id,max_id_type)
    return next_url

def get_data(url):
    mid = url.split('/')[-1]
    try:
        response = requests.get(url=url, headers=header).json()
        max_id = response.get('data')['max_id']
        max_id_type = response.get('data')['max_id_type']
        content_list = response.get('data').get('data')
        for item in content_list:
            global count
            count += 1
            created_at = item['created_at']
            user_id = item.get('user')['id']
            user_name = item.get('user')['screen_name']
            text = ''.join(re.findall('[\u4e00-\u9fa5]', item['text']))
            csv_data([count, created_at, user_id, user_name, text])
        print('第{}条数据'.format(count))
        time.sleep(2)
        if max_id != 0 :
            next_url = get_next_url(mid, max_id, max_id_type)
            get_data(next_url)
    except:
        print("下一页")

if __name__ == "__main__":
    csv_data(fileHeader)
    id_list = get_id_list()
    for id in id_list:
        url = get_url(id)
        get_data(url)
    print("爬取完成")





